<h2>Guide for ricing Windows 10</h2>

<a href="https://github.com/chloechantelle/rice/issues/new">Submit an issue</a> if there's any links/tips/content you want to submit to the guide.

Hosted on: 

https://www.ricing.chloechantelle.com

http://chloechantelle.github.io/ricing
