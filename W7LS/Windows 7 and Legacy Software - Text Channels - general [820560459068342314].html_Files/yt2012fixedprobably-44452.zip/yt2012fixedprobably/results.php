<?php
include("./static/header.php");
include("./static/guide.php");
?>
<div id="content">  
<div id="context-source-container" data-context-source="&quot;electric company&quot; and &quot;see sallys knee&quot;" style="display:none;"></div><div class="primary-col"><div class="search-header yt-uix-expander yt-uix-expander-collapsed">  <div class="filter-top">
    <div class="filter-bar-container">
      
      <ul class="filter-crumb-list"><li class="filter-crumb filter-crumb-ghost"><a class="filter"><span class="filter-text filter-ghost"></span><span class="yt-close" style="
    display: none;
">×</span></a></li></ul>
        

    </div>
  </div>
<div id="filter-dropdown" class="yt-uix-expander-body"><div class="filter-col"><h4 class="filter-col-title">Upload Date</h4><ul><li>
  

<a class="filter " title="Last hour" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+hour&amp;lclk=hour"><span class="filter-text filter-ghost">Last hour</span></a>
</li><li>
  

<a class="filter " title="Today" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+today&amp;lclk=today"><span class="filter-text filter-ghost">Today</span></a>
</li><li>
  

<a class="filter " title="This week" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+this+week&amp;lclk=this_week"><span class="filter-text filter-ghost">This week</span></a>
</li><li>
  

<a class="filter " title="This month" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+this+month&amp;lclk=this_month"><span class="filter-text filter-ghost">This month</span></a>
</li><li>
  

<a class="filter " title="This year" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+this+year&amp;lclk=this_year"><span class="filter-text filter-ghost">This year</span></a>
</li></ul></div><div class="filter-col"><h4 class="filter-col-title">Result Type</h4><ul><li>
  

<a class="filter " title="Video" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+video&amp;lclk=video"><span class="filter-text filter-ghost">Video</span></a>
</li><li>
  

<a class="filter " title="Channel" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+channel&amp;lclk=channel"><span class="filter-text filter-ghost">Channel</span></a>
</li><li>
  

<a class="filter " title="Playlist" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+playlist&amp;lclk=playlist"><span class="filter-text filter-ghost">Playlist</span></a>
</li><li>
  

<a class="filter " title="Movie" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+movie&amp;lclk=movie"><span class="filter-text filter-ghost">Movie</span></a>
</li><li>
  

<a class="filter " title="Show" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+show&amp;lclk=show"><span class="filter-text filter-ghost">Show</span></a>
</li></ul></div><div class="filter-col"><h4 class="filter-col-title">Duration</h4><ul><li>
  

<a class="filter " title="Short (~4 minutes)" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+short&amp;lclk=short"><span class="filter-text filter-ghost">Short (~4 minutes)</span></a>
</li><li>
  

<a class="filter " title="Long (20~ minutes)" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+long&amp;lclk=long"><span class="filter-text filter-ghost">Long (20~ minutes)</span></a>
</li></ul></div><div class="filter-col"><h4 class="filter-col-title">Features</h4><ul><li>
  

<a class="filter " title="HD (high definition)" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+hd&amp;lclk=hd"><span class="filter-text filter-ghost">HD (high definition)</span></a>
</li><li>
  

<a class="filter " title="CC (closed caption)" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+cc&amp;lclk=cc"><span class="filter-text filter-ghost">CC (closed caption)</span></a>
</li><li>
  

<a class="filter " title="Creative commons" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+creativecommons&amp;lclk=creativecommons"><span class="filter-text filter-ghost">Creative commons</span></a>
</li><li>
  

<a class="filter " title="3D" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+3d&amp;lclk=3d"><span class="filter-text filter-ghost">3D</span></a>
</li><li>
  

<a class="filter " title="Live" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_date_uploaded&amp;search_type=videos&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22%2C+live&amp;lclk=live"><span class="filter-text filter-ghost">Live</span></a>
</li></ul></div><div class="filter-col"><h4 class="filter-col-title">Sort by</h4><ul><li>

  

<a class="filter filter-sort " title="" href="/web/20130127182407/http://www.youtube.com/results?search_query=%22electric+company%22+and+%22see+sallys+knee%22&amp;search_type=videos"><span class="filter-text ">Relevance</span></a>
</li><li>

  

<span class="filter filter-sort filter-selected " title=""><span class="filter-text ">Upload date</span></span>
</li><li>

  

<a class="filter filter-sort " title="" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_view_count&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22&amp;search_type=videos"><span class="filter-text ">View count</span></a>
</li><li>

  

<a class="filter filter-sort " title="" href="/web/20130127182407/http://www.youtube.com/results?search_sort=video_avg_rating&amp;search_query=%22electric+company%22+and+%22see+sallys+knee%22&amp;search_type=videos"><span class="filter-text ">Rating</span></a>
</li></ul></div></div></div><div id="results">

      

    
  






  
    


    


    


      <ol id="search-results" class="result-list context-data-container">
                  


<?php
if(isset($_GET["page_token"])) {
$videoList = json_decode(file_get_contents('https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=15&pageToken='.urlencode($_GET["page_token"]).'&order=relevance&q='.urlencode($_GET["search_query"]).'&key='.$api_key));
} else {
$videoList = json_decode(file_get_contents('https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=15&order=relevance&q='.urlencode($_GET["search_query"]).'&key='.$api_key));
} 
		 
foreach($videoList->items as $item){
if(isset($item->id->videoId)){
if(isset($item->snippet->title)) {
echo "<li class='yt-lockup2 yt-lockup2-video yt-uix-tile context-data-item clearfix '>
   <div class='yt-lockup2-thumbnail'><a href='watch?v=".$item->id->videoId."' class='ux-thumb-wrap yt-uix-sessionlink yt-uix-contextlink contains-addto ' data-sessionlink='ei=CNGX56CUibUCFQo8RAodEEKIqg%3D%3D&amp;ved=CAMQwBs%3D'><span class='video-thumb ux-thumb yt-thumb-default-185 '><span class='yt-thumb-clip'><span class='yt-thumb-clip-inner'><img alt='Thumbnail' src='".$item->snippet->thumbnails->default->url."' width='185'><span class='vertical-align'></span></span></span></span>
      </a>
   </div>
   <div class='yt-lockup2-content'>
      <h3 class='yt-lockup2-title'><a class='yt-uix-sessionlink yt-uix-tile-link yt-uix-contextlink ' dir='ltr' data-sessionlink='ei=CNGX56CUibUCFQo8RAodEEKIqg%3D%3D&amp;ved=CAIQvxs%3D' href='watch?v=".$item->id->videoId."'>".htmlspecialchars($item->snippet->title)."</a></h3>
      <p class='yt-lockup2-meta'>  by <a href='profile?id=".$item->snippet->channelId."' class='yt-uix-sessionlink yt-user-name ' data-sessionlink='ei=CNGX56CUibUCFQo8RAodEEKIqg%3D%3D&amp;ved=CAQQwRs%3D' dir='ltr'>".$item->snippet->channelTitle."</a><span class='metadata-separator'>•</span>".$item->snippet->publishedAt."<span class='metadata-separator'>•</span></p>
      <p class='yt-lockup2-description' dir='ltr'>".mb_strimwidth(htmlspecialchars($item->snippet->description), 0, 50, "...")."</p>
      <div class='yt-lockup2-badges'>
         <ul class='item-badge-line'></ul>
      </div>
   </div>
</li>";
$pageToken = $videoList->nextPageToken;
}
}
}
?>

    

          



    

          



    

          



    

          



    

          



    

          



    

          



    

          



    


      </ol>





    

    
  <div class="promoted-videos pyv-promoted-videos">
    <ol class="context-data-container result-list">
          
    </ol>

      
      
  </div>




</div></div>  


<div class="yt-uix-pager" role="navigation">   
<a href="results?search_query=<?php echo urlencode($_GET["search_query"]); ?>&page_token=<?php echo $pageToken; ?>" class="yt-uix-button  yt-uix-pager-button yt-uix-sessionlink yt-uix-button-default" data-sessionlink="ei=CLHplbT-ibUCFcdRRAod3XcHTw%3D%3D" data-page="2"><span class="yt-uix-button-content">Next »</span></a>
    </div>
</div>