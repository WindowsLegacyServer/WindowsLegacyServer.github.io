<?php
include("./static/header.php");
include("./static/guide.php");
?>
<div id="content">
<p style="margin:12px;">Sorry, channels have not been implemented yet.</p></div>