<div id="guide">    <div id="guide-container">
    <div id="guide-main" class="guide-module  yt-uix-clickcard" data-orientation="vertical" data-position="bottomright" data-force-position="true" data-click-outside-persists="true" data-card-class="watch7-card-promo">
      <div class="guide-module-content ">
        <ul class="guide-toplevel">
          <li id="guide-subscriptions-section" class="guide-section guide-section-no-counts">
            <div id="guide-subs-footer-container">
                <div id="guide-subscriptions-container">
                    <div class="guide-channels-content">
      <ul id="guide-channels" class="guide-channels-list guide-item-container yt-uix-scroller filter-has-matches">
              <li class="guide-channel">
    <a class="guide-item  guide-item-selected narrow-item" href="#" title="Popular on YouTube" data-channel-id="youtube">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/tnHdj3df7iM/default.jpg" alt="Thumbnail" data-thumb-manual="1" src="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/tnHdj3df7iM/default.jpg" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>Popular on YouTube</span>
      </span>
    </a>
  </li>


              <li class="guide-channel">
    <a class="guide-item " href="#" title="Music" data-channel-id="HCp-Rdqh3z4Uc">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/p-Rdqh3z4Uc/default.jpg" alt="Thumbnail" data-thumb-manual="1" src="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/p-Rdqh3z4Uc/default.jpg" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>Music</span>
      </span>
    </a>
  </li>


              <li class="guide-channel">
    <a class="guide-item " href="#" title="Sports" data-channel-id="HC7Dr1BKwqctY">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="//web.archive.org/web/20121230023058/http://i4.ytimg.com/li/7Dr1BKwqctY/default.jpg" alt="Thumbnail" data-thumb-manual="1" src="//web.archive.org/web/20121230023058/http://i4.ytimg.com/li/7Dr1BKwqctY/default.jpg" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>Sports</span>
      </span>
    </a>
  </li>


              <li class="guide-channel">
    <a class="guide-item " href="#" title="Gaming" data-channel-id="HChfZhJdhTqX8">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/hfZhJdhTqX8/default.jpg" alt="Thumbnail" data-thumb-manual="1" src="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/hfZhJdhTqX8/default.jpg" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>Gaming</span>
      </span>
    </a>
  </li>


              <li class="guide-channel">
    <a class="guide-item " href="#" title="Movies" data-channel-id="UCczhp4wznQWonO7Pb8HQ2MQ">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="https://web.archive.org/web/20121230023058/http://i4.ytimg.com/i/czhp4wznQWonO7Pb8HQ2MQ/1.jpg" alt="Thumbnail" data-thumb-manual="1" src="https://web.archive.org/web/20121230023058/http://i4.ytimg.com/i/czhp4wznQWonO7Pb8HQ2MQ/1.jpg" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>Movies</span>
      </span>
    </a>
  </li>


              <li class="guide-channel">
    <a class="guide-item " href="#" title="TV Shows" data-channel-id="UCl8dMTqDrJQ0c8y23UBu4kQ">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="https://web.archive.org/web/20121230023058/http://i1.ytimg.com/i/l8dMTqDrJQ0c8y23UBu4kQ/1.jpg" alt="Thumbnail" data-thumb-manual="1" src="https://web.archive.org/web/20121230023058/http://i1.ytimg.com/i/l8dMTqDrJQ0c8y23UBu4kQ/1.jpg" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>TV Shows</span>
      </span>
    </a>
  </li>


              <li class="guide-channel">
    <a class="guide-item " href="#" title="News" data-channel-id="HCPvDBPPFfuaM">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/PvDBPPFfuaM/default.jpg" alt="Thumbnail" data-thumb-manual="1" src="//web.archive.org/web/20121230023058/http://i1.ytimg.com/li/PvDBPPFfuaM/default.jpg" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>News</span>
      </span>
    </a>
  </li>


              <li class="guide-channel">
    <a class="guide-item " href="#" title="Spotlight" data-channel-id="UCBR8-60-B28hp2BmDPdntcQ">
        <span class="thumb"><span class="video-thumb ux-thumb yt-thumb-square-18 "><span class="yt-thumb-clip"><span class="yt-thumb-clip-inner"><img data-thumb="https://web.archive.org/web/20121230023058/http://i2.ytimg.com/i/ULkRHBdLC5ZcEQBaL0oYHQ/1.jpg?v=50bd2bea" alt="Thumbnail" data-thumb-manual="1" src="https://web.archive.org/web/20121230023058/http://i2.ytimg.com/i/ULkRHBdLC5ZcEQBaL0oYHQ/1.jpg?v=50bd2bea" width="18"><span class="vertical-align"></span></span></span></span></span>
      <span class="display-name">
        <span>Spotlight</span>
      </span>
    </a>
  </li>


          <li id="guide-filter-no-results">
No channels found
          </li>
      </ul>
  </div>

                </div>
                <hr class="guide-section-separator">
            </div>
          </li>
        </ul>
            <div class="guide-section guide-header signup-promo guided-help-box">
    <p>
Sign in to add channels to your guide and for great recommendations!
    </p>
    <div id="guide-builder-promo-buttons" class="signed-out clearfix">
      <a href="https://web.archive.org/web/20121230023058/https://accounts.google.com/ServiceLogin?hl=en_US&amp;service=youtube&amp;uilel=3&amp;continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26hl%3Den_US%26next%3D%252F%253Ffeature%253Dsignin%26nomobiletemp%3D1&amp;passive=true" class="yt-uix-button   yt-uix-sessionlink yt-uix-button-hh-primary" data-sessionlink="ei=CPyeyIWLwbQCFZkQIQodPx8kow%3D%3D"><span class="yt-uix-button-content">Sign in ›</span></a>
    </div>
  </div>

          <div class="watch7-card-promo-content yt-uix-clickcard-content">
    <h3 class="watch7-card-promo-header">
      <img class="watch7-card-promo-guide-icon" src="//web.archive.org/web/20121230023058im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif">
This is your guide
    </h3>
    <div class="watch7-card-promo-message">
Access your channel, playlists, subscriptions, and more.
    </div>
    <div class="watch7-card-promo-account-line">
      <button onclick=";return false;" type="button" class=" yt-uix-button yt-uix-button-hh-primary" data-button-action="yt.www.guidev2.watch.acceptPromo" role="button"><span class="yt-uix-button-content">Got it! </span></button>
    </div>
  </div>

      </div>
    </div>
      <div id="watch-context-container" class="guide-module hid  yt-uix-clickcard" data-orientation="vertical" data-position="bottomright" data-force-position="true" data-click-outside-persists="true" data-card-class="watch7-card-promo">
          <div class="watch7-card-promo-content yt-uix-clickcard-content">
    <h3 class="watch7-card-promo-header">
      <img class="watch7-card-promo-context-icon" src="//web.archive.org/web/20121230023058im_/http://s.ytimg.com/yts/img/pixel-vfl3z5WfW.gif">
Never get lost
    </h3>
    <div class="watch7-card-promo-message">
Browse videos from the previous page, including the homepage feed, channel videos and search results.
    </div>
    <div class="watch7-card-promo-account-line">
      <button onclick=";return false;" type="button" class=" yt-uix-button yt-uix-button-hh-primary" data-button-action="yt.www.guidev2.watch.acceptPromo" role="button"><span class="yt-uix-button-content">Got it! </span></button>
    </div>
  </div>

      </div>
  </div>

</div>