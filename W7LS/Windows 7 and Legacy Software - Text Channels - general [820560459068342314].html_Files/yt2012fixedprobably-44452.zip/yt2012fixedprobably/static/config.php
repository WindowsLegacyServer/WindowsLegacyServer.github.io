<?php
$api_key = "AIzaSyCymXJc7FYmGipC99rAbp6ocFEpyPo6OK4"; // insert api key here
?>