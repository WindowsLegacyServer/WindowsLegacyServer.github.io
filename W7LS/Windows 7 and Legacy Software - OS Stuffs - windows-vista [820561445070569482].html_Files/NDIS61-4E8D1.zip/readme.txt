The driver package files in this folder can be used to install drivers for Intel(R) Gigabit devices on the following Operating Systems:
  *  Microsoft* Windows* Vista (x64 Edition)
  *  Microsoft Windows Server* 2008 (x64 Edition)