# Restore Vista WU

* A project to install working SHA-2 Windows Update for Windows Vista

______________________________

## Requirements

* Only the following Languages are supported by this project:

cs-CZ / Czech  
de-DE / German  
en-US / English  
es-ES / Spanish  
fr-FR / French  
hu-HU / Hungarian  
it-IT / Italian  
ja-JP / Japanese  
ko-KR / Korean  
nl-NL / Dutch  
pl-PL / Polish  
pt-BR / Portuguese (Brazil)  
pt-PT / Portuguese (Portugal)  
ru-RU / Russian  
sv-SE / Swedish  
tr-TR / Turkish  
zh-CN / Chinese Simplified  (China)  
zh-HK / Chinese Traditional (Hong Kong)  
zh-TW / Chinese Traditional (Taiwan)

* The following updates must be already installed (manually) before using this project:

KB4493730: Servicing stack update, April 2019  
KB4474419: SHA-2 code signing support update, September 2019

* Make sure that "Windows Management Instrumentation (winmgmt)" service is not disabled

______________________________

## How to Use

* Extract the pack contents to a folder with simple path, example C:\Downloads\VistaWUC

* Temporarily turn off Antivirus protection (if any), or exclude the extracted folder

* Make sure to install the prerequisite updates (reboot if required)

* Run "Install_WUC.cmd" as administrator

press y to continue and install WUC  
then, restart the system

* Run "Patch_WUC.cmd" as administrator

from the menu, choose the desired option:

[1] Patch WUC as Vista  
recieve official Vista updates only

[2] Patch WUC as Server2008  
recieve Server 2008 updates only (including ESU updates)

[3] Patch WUC as Server2008 + Vista  
recieve Vista updates and Server 2008 updates (including ESU updates)  
you may get duplicate updates with this option

[4] Remove Patched WUC  
this will only remove patched wuaueng6.dll, it does not uninstall updated WUC

______________________________

## Remarks

* To uninstall and remove updated WUC, run "Remove_WUC.cmd" as administrator

* To get ESU updates with Patch_WUC.cmd options [2] or [3], make sure to install KB4538484 or KB4575904, and the latest SSU

* You can switch between Patch_WUC.cmd options at any time  
but you may need to reboot afterward, and WU will need to rescan and repopulate its database

* You may need to install these updates manually to overcome WU long search issue:  
KB3205638, KB4012583, KB4015380, KB4019204, IE9-KB4018271

* Patch_WUC.cmd will remove "WU ESU Patcher" if detected

* Generally, Vista do not need BypassESU

______________________________

## Technical Info

* Microsoft discontinued legacy SHA-1 Windows Update endpoints for Windows XP and Vista in August 2020

* Server 2008 updates can be installed on Vista OS

however, certain components are excluded from installation, specially Windows Update Client which support SHA-2 endpoints

* Additionally, changing OS build to 6003 invalidated WU applicability rule for detecting Vista SP2 build 6002

b.WindowsVersion Comparison="EqualTo" MajorVersion="6" MinorVersion="0" BuildNumber="6002" ProductType="1"

* WU uses VerifyVersionInfoW function to evaluate b.WindowsVersion applicability rules

* kerneles.dll is a fake kernel32.dll which only modify VerifyVersionInfoW function, all other exported functions are forwarded to the original DLLs

______________________________

## Disclaimer

* This is a prototype project, it is not tested extensively, and could have unforseen issues

it is best to try it first on a test Vista system (or VM)

______________________________

## Credits

* IMI Kurwica / kerneles.dll  
* M2-Team / NSudoLC.exe  
* abbodi1406 / Project
