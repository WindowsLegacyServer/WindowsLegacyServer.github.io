run wlinstaller and uncheck ***everything*** except "photo gallery" and press add to installation

after the installation is complete copy paste the folders directly to c: